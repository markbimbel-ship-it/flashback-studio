# Flashback Studio (fixed v1)

Mobile-friendly photo correction app; processing is client-side and non-generative.

## Start
Open `index.html` in a browser. Choose a photo, optionally add reference images (preview only), choose a preset/format, adjust sliders, export.

## Features
- 17 preset looks (styles are collapsed by default)
- Photo gallery file picker
- Story/TikTok 9:16, Feed 4:5, original aspect ratio
- Brightness, contrast, saturation, warmth and basic sharpening controls
- Preview before export
- Local browser processing; source image is not overwritten

## Limitations
Reference images are only previewed, not transferred. Background replacement is not implemented. Crop is centered. No cloud account or backend.

## Hosting
Static site: upload `index.html` to GitHub, then deploy repository as a static site on Railway.
