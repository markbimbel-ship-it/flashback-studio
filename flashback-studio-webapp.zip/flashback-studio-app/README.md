# Flashback Studio (prototype)
Mobile-friendly photo editing starter, runs entirely in the browser. No server and no generative AI: brightness, contrast, saturation, warmth, simple sharpening and centered crops are performed locally with Canvas. The original uploaded file is not overwritten.

## Run
Open `index.html` in a modern browser or host the folder as a static site. Upload photo → choose style → choose format → fine-tune → export.

## Limitations
Styles are presets for slider values, not AI styles. Reference images are previewed but not applied. Background replacement isn't implemented. Crop is centered only. The identity lock means this tool does not generate or alter facial/body features; cropping/resizing/color edits still affect pixels globally. No image uploads to a server.
